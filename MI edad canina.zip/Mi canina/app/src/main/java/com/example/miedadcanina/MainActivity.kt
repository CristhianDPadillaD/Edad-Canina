package com.example.miedadcanina

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Calculando valores segun la interacción del aplicativo
        val ageEdit = findViewById<EditText>(R.id.age_edit)
        val resultText = findViewById<TextView>(R.id.resul_text)
        val button = findViewById<Button>(R.id.button)

        //Se recogen los datos, se hacen conversiones para operar por último
        button.setOnClickListener{
            val ageString:String = ageEdit.text.toString()
            if (ageString.isEmpty()){

                Toast.makeText( this,"Debes digitar tu edad", Toast.LENGTH_SHORT).show()

            }else {
                val ageInt: Int = ageString.toInt()
                val resultado: Int = ageInt * 7
                resultText.text = "Tu edad caninca es de $resultado años "
            }
        }

    }
}